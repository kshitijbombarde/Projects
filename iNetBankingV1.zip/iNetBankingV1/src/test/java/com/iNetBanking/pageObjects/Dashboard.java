package com.iNetBanking.pageObjects;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
public class Dashboard {
	
	//Web Elements
	@FindBy(xpath="//*[@id='content']/div/div[1]")
	@CacheLookup
	WebElement txtDashboard;
	
	@FindBy(xpath="//*[@id='header']/ul/li[2]/a")
	@CacheLookup
	WebElement btnAdmin;
	
	@FindBy(xpath="/html/body/header/ul/li[2]/ul/li[1]/a")
	@CacheLookup
	WebElement lnkLogout;
	
	//Actions
	public String getDashboardText(){
		String textDashboard = txtDashboard.getText();
		return textDashboard;
	}
	public void clickAdminBtn(){
		btnAdmin.click();
	}
	public void clickLogoutBtn(){
		lnkLogout.click();
	}
	
}
