package com.iNetBanking.testCases;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.iNetBanking.pageObjects.LoginPage;
public class TC01_LoginPage extends BaseClass {

	@Test(priority=1)
	public void loginTest() throws IOException{
		
		logger.info("URL is Opened in Browser");
		LoginPage lp = new LoginPage(driver);
		lp.setUserName(username);
		logger.info("Entered Username");
		lp.setPassword(password);
		logger.info("Enetered Password");
		
		lp.clickSubmit();
		logger.info("Login Button was Clicked");
		
		if(driver.getTitle().equals("Dashboard")){
			Assert.assertTrue(true);
			logger.info("Login Test Passed !");
		}
		else{
			captureScreen(driver,"LoginTest");
			Assert.assertTrue(false);
			logger.info("Login Test Failed !");
		}
		
	}
	
}
