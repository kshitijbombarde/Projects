package com.iNetBanking.testCases;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.iNetBanking.pageObjects.Dashboard;

public class TC02_DashboardStructure extends BaseClass {

	@Test(priority=2)
	public void dashboardTest() throws IOException {
		Dashboard dp = new Dashboard();
		String dText = dp.getDashboardText();
		if(dText.equals("Dashboard")){
			Assert.assertTrue(true);
			logger.info("Dashboard Text Was Verified Successfully, Test Case Passed !");
		}
		else{
			Assert.assertTrue(false);
			captureScreen(driver,"DashboardText");
			logger.info("Dashboard Text Was Not Verified, Test Case Failed !");
		}
		dp.clickAdminBtn();
		dp.clickLogoutBtn();
	}
	
}
