package com.iNetBanking.testSuite;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.iNetBanking.pageObjects.Dashboard;
import com.iNetBanking.pageObjects.LoginPage;
import com.iNetBanking.testCases.BaseClass;

public class TestSuite extends BaseClass{
	
	@Test(priority=1)
	public void loginTest() throws IOException{
		
		logger.info("URL is Opened in Browser");
		LoginPage lp = new LoginPage(driver);
		lp.setUserName(username);
		logger.info("Entered Username");
		lp.setPassword(password);
		logger.info("Enetered Password");
		
		lp.clickSubmit();
		logger.info("Login Button was Clicked");
		
		if(driver.getTitle().equals("Dashboard")){
			Assert.assertTrue(true);
			logger.info("Login Test Passed !");
		}
		else{
			captureScreen(driver,"LoginTest");
			Assert.assertTrue(false);
			logger.info("Login Test Failed !");
		}
	}
	
	@Test(priority=2)
	public void dashboardTest() throws IOException {
		Dashboard dp = new Dashboard();
		String dText = dp.getDashboardText();
		if(dText.equals("Dashboard")){
			Assert.assertTrue(true);
			logger.info("Dashboard Text Was Verified Successfully, Test Case Passed !");
		}
		else{
			Assert.assertTrue(false);
			captureScreen(driver,"DashboardText");
			logger.info("Dashboard Text Was Not Verified, Test Case Failed !");
		}
		dp.clickAdminBtn();
		dp.clickLogoutBtn();
	}
}
